﻿namespace ORM.Mappers
{
    class TerritoryMap
    {
    }
}
